export const SERVER_URL = "http://192.168.244.12:8080"
export const WS_SERVER_URL = "http://localhost:5000"