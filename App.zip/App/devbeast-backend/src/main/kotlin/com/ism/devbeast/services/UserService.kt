package com.ism.devbeast.services

import com.ism.devbeast.entities.User
import com.ism.devbeast.repositories.UserProjectRepository
import com.ism.devbeast.repositories.UserRepository
import com.ism.devbeast.requests.SignInRequest
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class UserService(
    @Autowired private val userRepository: UserRepository
) {

    fun getUserById(userId: String): User? {
        return userRepository.findById(userId).orElse(null);
    }

    fun getUserByName(userName: String) : User? {
        return userRepository.getUserByName(userName);
    }

    fun getUserByEmail(email: String): User? {
        return userRepository.getUserByEmail(email)
   }

    fun createUser(user: User): User? {
        val userInDB = userRepository.getUserByName(user.name)
        return if (userInDB == null) {
            userRepository.save(user)
        } else {
            null
        }
    }


    fun getUserId(signInRequest: SignInRequest): String? {
        val myUser = userRepository.getUserByName(signInRequest.userName)
        if (myUser == null) {
            return null
        }
        if (myUser.password != signInRequest.password) {
            return null
        }
        return myUser.userId
    }


}