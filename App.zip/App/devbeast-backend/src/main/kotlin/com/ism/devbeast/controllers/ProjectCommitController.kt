package com.ism.devbeast.controllers

import com.ism.devbeast.entities.ProjectCommit
import com.ism.devbeast.requests.GetDataRequest
import com.ism.devbeast.requests.ProjectCommitRequest
import com.ism.devbeast.services.ProjectCommitService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController


@RestController
@RequestMapping("/api/commit-project/")
class ProjectCommitController(
    @Autowired private val projectCommitService: ProjectCommitService
) {

    @PostMapping
    fun commitProject(@RequestBody project: ProjectCommitRequest): ProjectCommit {
        return projectCommitService.commitProject(project);
    }

    @PostMapping("/get-data")
    fun getProjectData(@RequestBody getDataRequest: GetDataRequest): ProjectCommit? {
        return projectCommitService.getProjectData(getDataRequest);
    }
}