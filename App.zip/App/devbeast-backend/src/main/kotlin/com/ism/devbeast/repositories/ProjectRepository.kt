package com.ism.devbeast.repositories

import com.ism.devbeast.entities.Project
import com.ism.devbeast.entities.User
import org.springframework.data.mongodb.repository.MongoRepository

interface ProjectRepository: MongoRepository<Project, String> {

    fun getProjectByProjectId(id: String): Project?
}