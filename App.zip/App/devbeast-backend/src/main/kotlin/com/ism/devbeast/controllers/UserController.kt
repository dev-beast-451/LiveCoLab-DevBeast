package com.ism.devbeast.controllers

import com.ism.devbeast.entities.User
import com.ism.devbeast.requests.SignInRequest
import com.ism.devbeast.requests.UserRequest
import com.ism.devbeast.responses.UserIdResponse
import com.ism.devbeast.services.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/users")
class UserController(
    @Autowired private val userService: UserService
) {

    @GetMapping("/{userId}")
    fun getUserByUserId(@PathVariable userId: String): User? {
        return userService.getUserById(userId);
    }

    @PostMapping
    fun createUser(@RequestBody userRequest: UserRequest): User? {

        val myUser = User(
            name = userRequest.userName,
            email = userRequest.email,
            password = userRequest.password
        )
        return userService.createUser(myUser);
    }

    @PostMapping("/signin")
    fun signIn(@RequestBody signInRequest: SignInRequest): UserIdResponse {
        return UserIdResponse(
            userId = userService.getUserId(signInRequest)
        );
    }
}