package com.ism.devbeast.services

import com.ism.devbeast.entities.Project
import com.ism.devbeast.entities.ProjectCommit
import com.ism.devbeast.repositories.ProjectCommitRepository
import com.ism.devbeast.repositories.ProjectRepository
import com.ism.devbeast.requests.GetDataRequest
import com.ism.devbeast.requests.ProjectCommitRequest
import com.ism.devbeast.requests.ProjectRequest
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ProjectCommitService(
    @Autowired private val projectCommitRepository: ProjectCommitRepository,
    @Autowired private val projectRepository: ProjectRepository
) {

    fun commitProject(projectCommitRequest: ProjectCommitRequest):ProjectCommit {

        val project = projectRepository.findById(projectCommitRequest.projectId).get()

        val newVersion = project.version + 1
        val updatedProject = project.copy(version = newVersion)
        projectRepository.save(updatedProject)

        val projectCommit = ProjectCommit(
            version = newVersion,
            projectId = project.projectId,
            data = projectCommitRequest.data,
            metaData = projectCommitRequest.metaData
        )
        return projectCommitRepository.save(projectCommit);
    }

    fun getProjectData(getDataRequest: GetDataRequest): ProjectCommit? {
        return projectCommitRepository.getDataByProjectIdAndVersion(getDataRequest.projectId, getDataRequest.version);
    }
}