package com.ism.devbeast.requests


data class ProjectCommitRequest(
    val projectId: String,
    val data: String,
    val metaData: String,
    val userId: String
)
