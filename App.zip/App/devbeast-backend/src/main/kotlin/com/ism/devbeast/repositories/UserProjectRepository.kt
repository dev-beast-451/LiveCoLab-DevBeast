package com.ism.devbeast.repositories

import com.ism.devbeast.entities.UserProject
import org.springframework.data.mongodb.repository.MongoRepository
import org.springframework.data.mongodb.repository.Query

interface UserProjectRepository: MongoRepository<UserProject, String> {

    fun findByUserId(userId: String): List<UserProject>
}
