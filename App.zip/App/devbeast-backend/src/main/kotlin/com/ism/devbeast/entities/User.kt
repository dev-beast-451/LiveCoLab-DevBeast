package com.ism.devbeast.entities

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import java.util.*

@Document
data class User(
    @Id
    val userId: String= UUID.randomUUID().toString(),
    val name: String,
    val email: String,
    val password: String
)
