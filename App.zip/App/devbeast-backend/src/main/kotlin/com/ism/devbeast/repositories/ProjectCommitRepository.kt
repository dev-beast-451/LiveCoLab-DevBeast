package com.ism.devbeast.repositories

import com.ism.devbeast.entities.ProjectCommit
import org.springframework.data.mongodb.repository.MongoRepository

interface ProjectCommitRepository: MongoRepository<ProjectCommit, String> {

    fun getDataByProjectIdAndVersion(projectId: String, version: Int): ProjectCommit?
}