package com.ism.devbeast.controllers

import com.ism.devbeast.entities.Project
import com.ism.devbeast.entities.User
import com.ism.devbeast.requests.ProjectRequest
import com.ism.devbeast.requests.UserRequest
import com.ism.devbeast.services.ProjectService
import com.ism.devbeast.services.UserProjectService
import com.ism.devbeast.services.UserService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/api/projects")
class ProjectController(
    @Autowired private val projectService: ProjectService,
    @Autowired private val userProjectService: UserProjectService
) {

    @GetMapping("/{projectId}")
    fun getProjectById(@PathVariable projectId: String): Project? {
        return projectService.getProjectById(projectId);
    }

    @PostMapping
    fun createProject(@RequestBody projectRequest: ProjectRequest): Project? {

        val myProject = Project(
            projectName = projectRequest.projectName
        )
        val savedProject =  projectService.createProject(myProject);

        val pid = savedProject?.projectId;

        userProjectService.saveMapping(userId = projectRequest.userId, projectId = pid!!);

        return savedProject;
    }

    @GetMapping("/userId/{userId}")
    fun getAllProjectsByUserId(@PathVariable userId: String): List<Project> {
        return projectService.getAllProjects(userId);
    }
}