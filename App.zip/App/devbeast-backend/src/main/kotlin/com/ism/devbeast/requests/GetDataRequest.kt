package com.ism.devbeast.requests

data class GetDataRequest (
    val projectId: String,
    val version: Int
)