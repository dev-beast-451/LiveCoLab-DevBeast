package com.ism.devbeast.responses

data class UserIdResponse(
    val userId: String?
)
