package com.ism.devbeast.requests

data class UserRequest(
    val userName: String,
    val email: String,
    val password: String
)
