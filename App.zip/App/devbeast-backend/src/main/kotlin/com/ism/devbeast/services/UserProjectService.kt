package com.ism.devbeast.services

import com.ism.devbeast.entities.UserProject
import com.ism.devbeast.repositories.UserProjectRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service


@Service
class UserProjectService(
    @Autowired private val userProjectRepository: UserProjectRepository
) {

    fun saveMapping(userId: String, projectId: String): UserProject {
        return userProjectRepository.save(UserProject(
            userId = userId,
            projectId = projectId
        ));
    }

    fun getProjectIdsByUserId(userId: String): List<String> {
        return userProjectRepository.findByUserId(userId).map { it.projectId };
    }
}