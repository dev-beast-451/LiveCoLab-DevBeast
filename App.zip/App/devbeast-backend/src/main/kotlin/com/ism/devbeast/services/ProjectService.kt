package com.ism.devbeast.services

import com.ism.devbeast.entities.Project
import com.ism.devbeast.entities.User
import com.ism.devbeast.repositories.ProjectRepository
import com.ism.devbeast.repositories.UserRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.stereotype.Service

@Service
class ProjectService(
    @Autowired private val projectRepository: ProjectRepository,
    @Autowired private val userProjectService: UserProjectService
) {

    fun getProjectById(id: String): Project? {
        return projectRepository.getProjectByProjectId(id);
    }

    fun createProject(project: Project) : Project? {
        return projectRepository.save(project);
    }

    fun getAllProjects(userId: String): List<Project> {
        val projectIds = userProjectService.getProjectIdsByUserId(userId)

        val allProjects = projectIds.mapNotNull { projectId ->
            projectRepository.getProjectByProjectId(projectId)
        }
        return allProjects
    }
}