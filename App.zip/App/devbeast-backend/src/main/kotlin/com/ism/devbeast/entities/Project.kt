package com.ism.devbeast.entities

import org.springframework.data.annotation.Id
import org.springframework.data.mongodb.core.mapping.Document
import java.util.UUID

@Document
data class Project(
    @Id
    val projectId: String = UUID.randomUUID().toString(),
    val projectName: String,
    val version: Int = 0
)
