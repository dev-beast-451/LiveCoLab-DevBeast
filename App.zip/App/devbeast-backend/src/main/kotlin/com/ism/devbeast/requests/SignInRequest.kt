package com.ism.devbeast.requests

data class SignInRequest(
    val userName: String,
    val password: String
)
