package com.ism.devbeast

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class LivecolabApplication

fun main(args: Array<String>) {
	runApplication<LivecolabApplication>(*args)
}
