package com.ism.devbeast.repositories

import com.ism.devbeast.entities.User
import org.springframework.data.mongodb.repository.MongoRepository

interface UserRepository: MongoRepository<User, String> {

    fun getUserByName(username: String): User?

    fun getUserByEmail(email: String): User?
}