package com.ism.devbeast.requests

data class ProjectRequest(
    val projectName: String,
    val userId: String
)
