package com.ism.devbeast

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class LivecolabApplicationTests {

	@Test
	fun contextLoads() {
	}

}
